#PostgreSQL
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'postgres',
        'USER': 'postgres',
        'PASSWORD': 'NjczOS1yYW1kcGh5',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}
INSTALLED_APPS = (
    'standalone',
)
SECRET_KEY = 'SECRET KEY for this Django Project'